#include <cstdio>
#include <cstring>
#include <mpi.h>

int main(int argc, char* argv[]) {
	MPI::Init(argc, argv);
	int n_of_tasks = MPI::COMM_WORLD.Get_size();
	int rank = MPI::COMM_WORLD.Get_rank();

	int name_len;
	char processor_name[MPI_MAX_PROCESSOR_NAME];
	MPI::Get_processor_name(processor_name, name_len);

	if (rank == 0) {
		char buffer[] = "Hello!";
		int count = std::strlen(buffer) + 1;
		int dest = 1;

		int tag = 0;
		MPI::COMM_WORLD.Send(&count, 1, MPI::INT, dest, tag);
		tag = 1;
		MPI::COMM_WORLD.Send(buffer, count, MPI::CHAR, dest, tag);

		std::printf("I'am %d (%s): Message: \"%s\" from %d to %d\n", 0,
                processor_name, buffer, 0, 1);

		int source = n_of_tasks - 1;
		tag = 0;
		MPI::COMM_WORLD.Recv(&count, 1, MPI::INT, source, tag);
		tag = 1;
		MPI::COMM_WORLD.Recv(buffer, count, MPI::CHAR, source, tag);
		std::printf("\nRing complete\n");

	} else {
		for (int i = 1; i <= n_of_tasks; i++) {
			if (rank == i) {
				char buffer[100];
				int tag = 0;
				int count;
				int source = i - 1;
				int dest = (i + 1) % n_of_tasks;

				tag = 0;
				MPI::COMM_WORLD.Recv(&count, 1, MPI::INT, source, tag);
				tag = 1;
				MPI::COMM_WORLD.Recv(buffer, count, MPI::CHAR, source, tag);

				tag = 0;
				MPI::COMM_WORLD.Send(&count, 1, MPI::INT, dest, tag);
				tag = 1;
				MPI::COMM_WORLD.Send(buffer, count, MPI::CHAR, dest, tag);

				std::printf("I'am %d (%s): Message: \"%s\" from %d -> this ->\
                          to %d\n", rank, processor_name, buffer, source, dest);
			}
		}
	}
	MPI::Finalize();
}
