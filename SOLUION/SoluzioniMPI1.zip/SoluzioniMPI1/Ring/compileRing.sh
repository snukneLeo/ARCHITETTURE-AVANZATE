mpicxx ../Ring.cpp -std=c++11 -o ring
