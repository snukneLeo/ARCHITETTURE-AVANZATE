#include <cstdio>
#include <cstring>
#include <mpi.h>
#include <iostream>     // std::cout, std::fixed
#include <iomanip>      // std::setprecision
#include <algorithm>
#include <random>

int main(int argc, char* argv[]) {
	MPI::Init(argc, argv);
	MPI::COMM_WORLD.Set_errhandler(MPI::ERRORS_THROW_EXCEPTIONS);

	int n_of_tasks = MPI::COMM_WORLD.Get_size();
	int rank = MPI::COMM_WORLD.Get_rank();

	int name_len;
	char processor_name[MPI_MAX_PROCESSOR_NAME];
	MPI::Get_processor_name(processor_name, name_len);

	const int root = 0;
	int size;

	int* Seeds = new int[n_of_tasks];
	if (rank == 0) {
		size = 1 << 15;
		for (int i = 0; i < n_of_tasks; i++)
			Seeds[i] = (i + 500) % 51;
	}

	try {
		int recvseed;
		MPI::COMM_WORLD.Bcast(&size, 1, MPI::INT, root);
		MPI::COMM_WORLD.Scatter(Seeds, 1, MPI::INT, &recvseed,
                                1, MPI::INT, root);

		std::printf("rank %d  myseed %d  mysize %d\n", rank, recvseed, size);

        int histogram_size = 'Z' - 'A' + 1;
		std::default_random_engine generator (recvseed);
		std::normal_distribution<double> distribution(histogram_size / 2, histogram_size / 4);//'A', 'Z' + 1

		int* localHistogram  = new int[histogram_size]();
		for (int i = 0; i < size; ++i) {
            int value = distribution(generator);
            if (value >= 0 && value < histogram_size)
			     localHistogram[ value ]++;
        }

		int* totalHistogram = new int[histogram_size];
		MPI::COMM_WORLD.Reduce(localHistogram, totalHistogram, histogram_size,
                               MPI::INT, MPI::SUM, root);

		if (rank == root) {
            int max = *std::max_element(totalHistogram,
                                        totalHistogram + histogram_size);

			std::cout << "Total Histogram:" << std::endl;
			for (int i = 0; i < histogram_size; ++i) {
				std::cout << static_cast<char>('A' + i) << "\t"
                    << std::string(
                       std::round( (double) totalHistogram[i] / max * 10), '*')
                    << std::endl;
            }
			std::cout << std::endl;
		}
	}
	catch (MPI::Exception e) {
		std::cout << "MPI ERROR: " << e.Get_error_code()
				  << " -" << e.Get_error_string() << std::endl;
	}
	MPI::Finalize();
}
