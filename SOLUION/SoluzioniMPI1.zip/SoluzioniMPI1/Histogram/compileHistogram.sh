mpicxx ../Histogram.cpp -std=c++0x -o histogram
