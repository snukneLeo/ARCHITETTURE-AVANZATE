#include <cstdio>
#include <mpi.h>
#include <algorithm>

int main(int argc, char* argv[]) {
	MPI::Init(argc, argv);
	int n_of_tasks = MPI::COMM_WORLD.Get_size();
	int rank = MPI::COMM_WORLD.Get_rank();

	int name_len;
	char processor_name[MPI_MAX_PROCESSOR_NAME];
	MPI::Get_processor_name(processor_name, name_len);

	if (rank == 0) {
		for (int dest = 1; dest < n_of_tasks; dest++) {
			int tag = 0;
			int data = 1;

			double startTime = MPI::Wtime();
			MPI::COMM_WORLD.Send(&data, 1, MPI::INT, dest, tag);
			MPI::COMM_WORLD.Recv(&data, 1, MPI::INT, dest, tag);
			double endTime = MPI::Wtime();

			std::printf("Elasped time for rank %d: %f ms\n",
                        dest, ((endTime - startTime) / 2) * 1000);
		}
	} else {
		int tag = 0;
		int data;
		MPI::COMM_WORLD.Recv(&data, 1, MPI::INT, 0, tag);
		MPI::COMM_WORLD.Send(&data, 1, MPI::INT, 0, tag);
	}

	MPI::COMM_WORLD.Barrier();

	const int size = (1 << 25);
	if (rank == 0) {
		int* data = new int[size];
		std::fill(data, data + size, 3);

		for (int dest = 1; dest < n_of_tasks; dest++) {
			int tag = 0;

			double startTime = MPI::Wtime();
			MPI::COMM_WORLD.Send(data, size, MPI::INT, dest, tag);
			MPI::COMM_WORLD.Recv(data, size, MPI::INT, dest, tag);
			double endTime = MPI::Wtime();

			std::printf("Bandwidth for rank %d: %f MByte/s\n", dest,
                        ((double) size / (1 << 20)) / (endTime - startTime));
		}
	} else {
		int tag = 0;
		int* data = new int[size];
		MPI::COMM_WORLD.Recv(data, size, MPI::INT, 0, tag);
		int response = 1;
		MPI::COMM_WORLD.Send(&response, 1, MPI::INT, 0, tag);
	}

	MPI::Finalize();
}
