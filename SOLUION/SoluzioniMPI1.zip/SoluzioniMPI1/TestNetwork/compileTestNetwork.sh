mpicxx ../TestNetwork.cpp -std=c++11 -o testnetwork
