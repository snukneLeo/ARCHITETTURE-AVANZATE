#include <cstdio>
#include <cstring>
#include <mpi.h>
#include <iostream>     // std::cout, std::fixed
#include <iomanip>      // std::setprecision
#include <algorithm>
#include <random>
#include <chrono>
#include <sstream>

const int N = 4;

void printSquareMatrix(int* Matrix, int N, const char str[] = "", int rank = -1);
void printSquareMatrix(int** Matrix, int N, const char str[] = "", int rank = -1);
void printRow(int* Row, int N, const char str[] = "", int rank = -1);
void printCol(int* Col, int N, int colIndex, const char str[] = "", int rank = -1);

int main(int argc, char* argv[]) {
	MPI::Init(argc, argv);
	MPI::COMM_WORLD.Set_errhandler(MPI::ERRORS_THROW_EXCEPTIONS);

	int n_of_tasks = MPI::COMM_WORLD.Get_size();
	int rank = MPI::COMM_WORLD.Get_rank();

	int name_len;
	char processor_name[MPI_MAX_PROCESSOR_NAME];
	MPI::Get_processor_name(processor_name, name_len);

	unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
	std::default_random_engine generator (seed);
	std::uniform_int_distribution<int> distribution(1, 100);

	// ------------------- INIT -----------------------------------------
	const int root = 0;

	int* MatrixA, *MatrixB;
	if (rank == root) {
		MatrixA = new int[N * N];
		MatrixB = new int[N * N];
		for (int i = 0; i < N; ++i) {
			for (int j = 0; j < N; ++j) {
				MatrixA[i * N + j] = distribution(generator);
				MatrixB[i * N + j] = distribution(generator);
			}
		}
		printSquareMatrix(MatrixA, N, "Matrix A\n");
		printSquareMatrix(MatrixB, N, "Matrix B\n");
	}

	const int item_per_task = N / n_of_tasks;

	// ------------------- PREPARE DATA STRUCTURES AND TYPES ----------------------------------------- *

	MPI::Datatype RowType = MPI::INT.Create_contiguous(N);
	MPI::Datatype ColType = MPI::INT.Create_vector(N, item_per_task, N);
	RowType.Commit();
	ColType.Commit();

	int* recvRows = new int[item_per_task * N]();
	int* recvCols = new int[N * N]();
	int* MatrixC = new int[N * N]();
	int* TransposeMatrixC = new int[N * N]();

	// ------------------- RUN ----------------------------------------- *

	MPI::COMM_WORLD.Scatter(&MatrixA[0], item_per_task, RowType, recvRows, item_per_task, RowType, root);
	printRow(recvRows, N, "recvRow\n", rank);

	if (rank == root) {
		for (int i = 1; i < n_of_tasks; ++i)
			MPI::COMM_WORLD.Send(&MatrixB[i], item_per_task, ColType, i, 0);
		for (int i = 0; i < N; ++i)
			recvCols[i * N] = MatrixB[i * N];
	} else
		MPI::COMM_WORLD.Recv(recvCols, item_per_task, ColType, root, 0);

	//MPI::COMM_WORLD.Scatter(&MatrixB[0], item_per_task, ColType, recvCols, item_per_task, ColType, root);		//error
	printCol(recvCols, N, 0, "recvCol\n", rank);

	int* result = new int[item_per_task]();
	for (int i = 0; i < item_per_task; ++i) {
		for (int j = 0; j < N; ++j)
			result[i] += recvRows[i * N + j] * recvCols[N * j];
	}
	printRow(recvRows, item_per_task, "result\n", rank);

	MPI::COMM_WORLD.Allgather(result, item_per_task, MPI::INT, MatrixC, item_per_task, MPI::INT);

	printSquareMatrix(MatrixC, N, "Matrix C\n", rank);
	for (int i = 1; i < N; ++i) {
		for (int j = 0; j < N; ++j)
			MatrixC[i * N + j] = MatrixC[j] * (i + 1);
	}

	MPI::COMM_WORLD.Alltoall(MatrixC, N / n_of_tasks, MPI::INT, TransposeMatrixC,  N / n_of_tasks, MPI::INT);
	printSquareMatrix(MatrixC, N, "Matrix C\n", rank);

	MPI::Finalize();
}


void printSquareMatrix(int* Matrix, int N, const char str[], int rank) {
	std::stringstream ss;
	if (rank >= 0)
		ss << "rank " << rank << "-> ";
	ss << str;
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++)
			ss << std::setw(5) << Matrix[i * N + j] << ' ';
		ss << std::endl;
	}
	ss << std::endl << std::endl;
	std::cout << ss.str();
}

void printSquareMatrix(int** Matrix, int N, const char str[], int rank) {
	std::stringstream ss;
	if (rank >= 0)
		ss << "rank " << rank << "-> ";
	ss << str;
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++)
			ss << std::setw(5) << Matrix[i][j] << ' ';
		ss << std::endl;
	}
	ss << std::endl << std::endl;
	std::cout << ss.str();
}

void printRow(int* Row, int N, const char str[], int rank) {
	std::stringstream ss;
	if (rank >= 0)
		ss << "rank " << rank << "-> ";
	ss << str;
	for (int i = 0; i < N; i++)
		ss << Row[i] << ' ';
	ss << std::endl << std::endl;
	std::cout << ss.str();
}

void printCol(int* Col, int N, int colIndex, const char str[], int rank) {
	std::stringstream ss;
	if (rank >= 0)
		ss << "rank " << rank << "-> ";
	ss << str;
	for (int i = 0; i < N; i++)
		ss << Col[N * i + colIndex] << std::endl;
	ss << std::endl;
	std::cout << ss.str();
}

//@author Federico Busato