#include <cstdio>
#include <cstring>
#include <cmath>		//ceil, sqrt 
#include <mpi.h>
#include <iostream>     // std::cout, std::fixed
#include <iomanip>      // std::setprecision
#include <algorithm>
#include <random>
#include <chrono>
#include <sstream>
#include <vector> 

const int N = 16;

void printArray(int* Array, int N, const char str[] = "", int rank = -1);

int main(int argc, char* argv[]) {
	MPI::Init(argc, argv);
	MPI::COMM_WORLD.Set_errhandler(MPI::ERRORS_THROW_EXCEPTIONS);

	int n_of_tasks = MPI::COMM_WORLD.Get_size();
	int rank = MPI::COMM_WORLD.Get_rank();

	int name_len;
	char processor_name[MPI_MAX_PROCESSOR_NAME];
	MPI::Get_processor_name(processor_name, name_len);

	unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
	std::default_random_engine generator (seed);
	std::uniform_int_distribution<int> distribution(1, 100);

	// ------------------- INIT -----------------------------------------
	const int root = 0;

	int* RandomValues;
	int* array_of_blocklengths, *array_of_displacements;
	int* rootFinalResult, *rootFinalBlockLength, *rootFinalDisplacement;
		
	if (rank == root) {
		RandomValues = new int[N];
		for (int i = 0; i < N; ++i)
			RandomValues[i] = distribution(generator);

		array_of_blocklengths = new int[n_of_tasks];
		array_of_displacements = new int[n_of_tasks + 1];

		int sum = 0;
		float denom = (n_of_tasks * n_of_tasks + n_of_tasks) / 2;
		for (int i = 0; i < n_of_tasks - 1; ++i) {
			array_of_blocklengths[i] = floor(((i + 1) / denom) * N);
			sum += array_of_blocklengths[i];
		}
		array_of_blocklengths[n_of_tasks - 1] = N - sum; 
		
		array_of_displacements[0] = 0;
		std::partial_sum(array_of_blocklengths, array_of_blocklengths + n_of_tasks, array_of_displacements + 1);
		
		printArray(RandomValues, N, "RandomValues\n");
		printArray(array_of_blocklengths, n_of_tasks, "blocklenght\n");
		printArray(array_of_displacements, n_of_tasks + 1, "Displace\n");
	}
	MPI::COMM_WORLD.Barrier();
	
	int RankCount;
	MPI::COMM_WORLD.Scatter(array_of_blocklengths, 1,  MPI::INT, &RankCount, 1, MPI::INT, root);

	//printf("rank %d -> rankcount %d\n", rank, RankCount);
	//MPI::COMM_WORLD.Barrier();
	
	// only root knows  "array_of_displacements"
	int* RecvValues = new int[N];
	MPI::COMM_WORLD.Scatterv(RandomValues, array_of_blocklengths, array_of_displacements, MPI::INT,
							 RecvValues, RankCount,  MPI::INT, root);

	//printArray(RecvValues, RankCount, "recvValues\n", rank);
	//MPI::COMM_WORLD.Barrier();
		
	int* sendBackValues = new int[N];
	auto it = std::copy_if(RecvValues, RecvValues + RankCount, sendBackValues, [](int x){ return (x % 3) == 0; });
	int sendBackValuesSize = it - sendBackValues;
	
	/*printf("rank %d -> sendBackValuesSize %d\n", rank, sendBackValuesSize);
	printArray(sendBackValues, sendBackValuesSize, "sendBackValuesSize\n", rank);
	MPI::COMM_WORLD.Barrier();*/
	
	if (rank == root) {
		rootFinalResult	= new int[N];
		rootFinalBlockLength = new int[n_of_tasks];
		rootFinalDisplacement = new int[n_of_tasks + 1];
	}
	
	MPI::COMM_WORLD.Gather(&sendBackValuesSize, 1, MPI::INT, rootFinalBlockLength, 1, MPI::INT, root);

	if (rank == root) {
		rootFinalDisplacement[0] = 0;
		std::partial_sum(rootFinalBlockLength, rootFinalBlockLength + n_of_tasks, rootFinalDisplacement + 1);
	}
	
	MPI::COMM_WORLD.Gatherv(sendBackValues, sendBackValuesSize, MPI::INT, rootFinalResult,
							rootFinalBlockLength, rootFinalDisplacement, MPI::INT, root);

	if (rank == 0)
		printArray(rootFinalResult, rootFinalBlockLength[n_of_tasks - 1] + rootFinalDisplacement[n_of_tasks - 1], "final\n", rank);
						
	MPI::Finalize();
}

void printArray(int* Array, int N, const char str[], int rank) {
	std::stringstream ss;
	if (rank >= 0)
		ss << "rank " << rank << "-> ";
	ss << str;
	for (int i = 0; i < N; i++)
		ss << Array[i] << ' ';
	ss << std::endl << std::endl;
	std::cout << ss.str();
}

//@author Federico Busato